import { Play } from "lucide-react";
import { Button } from "@/components/ui/button";

const Showreel = () => {
  return (
    <section className="py-20 bg-card/50">
      <div className="container mx-auto px-4">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              <span className="text-gradient">Showreel</span>
            </h2>
            <p className="text-xl text-muted-foreground">
              A compilation of my best work
            </p>
          </div>
          
          <div className="relative aspect-video bg-muted rounded-lg overflow-hidden group cursor-pointer card-hover">
            <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent" />
            <div className="absolute inset-0 flex items-center justify-center">
              <Button size="lg" className="gap-2">
                <Play className="w-6 h-6" />
                Watch Showreel
              </Button>
            </div>
            <div className="absolute bottom-6 left-6 right-6">
              <div className="flex items-center justify-between text-sm">
                <span className="text-foreground/80">Duration: 2:45</span>
                <span className="text-foreground/80">12 Featured Projects</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Showreel;
