import { Card, CardContent } from "@/components/ui/card";
import { Play } from "lucide-react";
import videoThumb1 from "@/assets/video-thumb-1.jpg";
import videoThumb2 from "@/assets/video-thumb-2.jpg";
import videoThumb3 from "@/assets/video-thumb-3.jpg";
import videoThumb4 from "@/assets/video-thumb-4.jpg";
import videoThumb5 from "@/assets/video-thumb-5.jpg";
import videoThumb6 from "@/assets/video-thumb-6.jpg";

const projects = [
  {
    id: 1,
    title: "Commercial Product",
    category: "Commercial",
    image: videoThumb1,
  },
  {
    id: 2,
    title: "Corporate Event",
    category: "Corporate",
    image: videoThumb2,
  },
  {
    id: 3,
    title: "Music Video",
    category: "Music",
    image: videoThumb3,
  },
  {
    id: 4,
    title: "Documentary",
    category: "Documentary",
    image: videoThumb4,
  },
  {
    id: 5,
    title: "Brand Story",
    category: "Branding",
    image: videoThumb5,
  },
  {
    id: 6,
    title: "Wedding Film",
    category: "Lifestyle",
    image: videoThumb6,
  },
];

const Portfolio = () => {
  return (
    <section className="py-20 px-4" id="portfolio">
      <div className="container mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">Featured Work</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Explore a selection of my recent video editing projects across various genres
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project) => (
            <Card 
              key={project.id} 
              className="overflow-hidden border-0 bg-card card-hover cursor-pointer group"
              style={{ boxShadow: 'var(--shadow-card)' }}
            >
              <CardContent className="p-0 relative">
                <div className="aspect-video relative overflow-hidden">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-background/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                    <div className="w-16 h-16 rounded-full bg-primary flex items-center justify-center">
                      <Play className="w-8 h-8 text-primary-foreground ml-1" />
                    </div>
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-semibold mb-2">{project.title}</h3>
                  <p className="text-sm text-accent">{project.category}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Portfolio;
