import { Card, CardContent } from "@/components/ui/card";
import { Film, Scissors, Palette, Zap } from "lucide-react";

const skills = [
  {
    icon: Film,
    title: "Color Grading",
    description: "Professional color correction and cinematic grading",
  },
  {
    icon: Scissors,
    title: "Precision Editing",
    description: "Frame-perfect cuts and seamless transitions",
  },
  {
    icon: Palette,
    title: "Visual Effects",
    description: "Motion graphics and stunning visual effects",
  },
  {
    icon: Zap,
    title: "Fast Turnaround",
    description: "Efficient workflow without compromising quality",
  },
];

const About = () => {
  return (
    <section className="py-20 px-4 bg-secondary/20" id="about">
      <div className="container mx-auto">
        <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
          <div>
            <h2 className="text-4xl md:text-5xl font-bold mb-6">About My Work</h2>
            <p className="text-lg text-muted-foreground mb-4">
              With over a decade of experience in video editing, I specialize in transforming raw footage into compelling visual narratives. My passion lies in the details - every cut, transition, and color grade is carefully crafted to evoke emotion and tell powerful stories.
            </p>
            <p className="text-lg text-muted-foreground">
              From commercial projects to documentaries, music videos to corporate content, I bring a cinematic approach to every project, ensuring your vision comes to life with professional polish and creative flair.
            </p>
          </div>
          <div className="grid grid-cols-2 gap-4">
            {skills.map((skill) => (
              <Card key={skill.title} className="border-border/50 bg-card/50 backdrop-blur">
                <CardContent className="p-6 text-center">
                  <skill.icon className="w-10 h-10 mx-auto mb-3 text-accent" />
                  <h3 className="font-semibold mb-2">{skill.title}</h3>
                  <p className="text-sm text-muted-foreground">{skill.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
