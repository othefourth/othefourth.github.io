import { Button } from "@/components/ui/button";
import { Mail, Phone, MapPin } from "lucide-react";

const Contact = () => {
  return (
    <section className="py-20 px-4" id="contact">
      <div className="container mx-auto max-w-4xl text-center">
        <h2 className="text-4xl md:text-5xl font-bold mb-6">Let's Create Together</h2>
        <p className="text-xl text-muted-foreground mb-12">
          Ready to bring your project to life? Get in touch and let's discuss how we can create something amazing together.
        </p>
        
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          <div className="flex flex-col items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center">
              <Mail className="w-6 h-6 text-accent" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground mb-1">Email</p>
              <p className="font-medium">hello@example.com</p>
            </div>
          </div>
          
          <div className="flex flex-col items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center">
              <Phone className="w-6 h-6 text-accent" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground mb-1">Phone</p>
              <p className="font-medium">+1 (555) 123-4567</p>
            </div>
          </div>
          
          <div className="flex flex-col items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center">
              <MapPin className="w-6 h-6 text-accent" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground mb-1">Location</p>
              <p className="font-medium">Los Angeles, CA</p>
            </div>
          </div>
        </div>
        
        <Button variant="hero" size="lg">
          Start a Project
        </Button>
      </div>
    </section>
  );
};

export default Contact;
